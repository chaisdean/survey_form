from django.shortcuts import render, redirect, HttpResponse

# Create your views here.
def result(request):
    return render(request, 'result/result.html')
