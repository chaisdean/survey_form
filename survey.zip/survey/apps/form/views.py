from __future__ import unicode_literals
from django.shortcuts import render, redirect, HttpResponse

# Create your views here.
def form(request):
    return render(request, 'form/form.html')

def result(request):
    return render(request, 'form/result.html')

def process(request):
    try:
        request.session['submit']
    except KeyError:
        request.session['submit'] = 0

    request.session['name'] = request.POST['name']
    request.session['location'] = request.POST['location']
    request.session['language'] = request.POST['language']
    request.session['comment'] = request.POST['comment']
    request.session['submit'] += 1
    return redirect('/result')

def back(request):
    return redirect('/')
